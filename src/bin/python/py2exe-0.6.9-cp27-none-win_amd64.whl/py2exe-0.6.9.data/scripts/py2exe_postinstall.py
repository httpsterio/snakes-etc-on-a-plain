"""py2exe is now installed on your machine.

There are some samples in the 'samples' subdirectory."""

import sys

if len(sys.argv) == 2 and sys.argv[1] == "-install":
    print __doc__
